# CNN_MNIST-
==简单的CNN网络实现mnist手写数据集的识别，并实现保存模型和调用模型进行检测==       


code:    

network : 整个网络部分    

train ： 训练的部分，并保存模型    

test ： 对训练好的模型进行调用，并可以对单张的 jpg 格式的mnsit数据集进行测试     


rar: 所有的代码打包结果，以及mnist数据集 和 jpg的测试图片    

